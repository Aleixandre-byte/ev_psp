package ev3;

public class Mina {
	private int stock;
	
	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public Mina(int cant) {
		this.stock = cant;
	}

	public static void main(String[] args) {
		

	}

}
