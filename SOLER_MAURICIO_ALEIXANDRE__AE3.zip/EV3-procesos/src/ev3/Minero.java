package ev3;

public class Minero implements Runnable{
	
	private int bolsa,tiempoExtraccion;
	private String nombre;
	private Mina mina;
	
	public Minero(String nombre,Mina m) {
		bolsa = 0;	
	this.mina = m;
	this.nombre = nombre;
	}
	
	public void extraerRecurso() {
		int total = 0;
		while(mina.getStock() > 0) {
			mina.setStock(mina.getStock()-1);
			bolsa += 1;	
			total += bolsa;
			System.out.println(nombre+" ha extraido "+bolsa+" de oro");	
		}
		//System.out.println(nombre+"TOTAL-> "+total);
	
	}
	public void run() {
		extraerRecurso();
	}
	
	public int getBolsa() {
		return bolsa;
	}

	public void setBolsa(int bolsa) {
		this.bolsa = bolsa;
	}

	
}
