package ev3;

import java.util.ArrayList;
import java.util.Scanner;

public class app {

	public static void main(String[] args) {
		ArrayList<Minero> listaMinero = new ArrayList<Minero>();
		int stock;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce stock: ");
		stock = Integer.parseInt(teclado.nextLine());
		Mina m = new Mina(stock);
		int total = 0;
		
		for (int i = 0; i < 10; i++) {
			Minero minero = new Minero("Minero"+(i+1),m);
			listaMinero.add(minero);
		}
		
		Thread t;
		
		for (int i = 0; i < 10; i++) {
			t = new Thread(listaMinero.get(i));
			t.setName("Minero" + (i+1));
			t.start();
		}
		try {
			Thread.sleep(1000);
			} catch (InterruptedException e) {
			e.printStackTrace();
			}
		
		for (int i = 0; i < 10; i++) {
			total += listaMinero.get(i).getBolsa();
		}

		
		System.out.println("Total de la bolsa: "+total);
		System.out.println("Mina stock: "+m.getStock());
	}

}
